/* 
 * File:   tmr2.h
 * Author: AdminFZ
 *
 * Created on May 29, 2025, 4:00 PM
 */

#ifndef TMR2_H
#define	TMR2_H

#ifdef	__cplusplus
extern "C" {
#endif
#include <xc.h>
#include "macrosFZ.h"    
#include "pwm1.h"

#define psc2 3
   
    void TMR2_Start(void);
    void TMR2_Stop(void);
    void TMR2_initialize(void);
#ifdef	__cplusplus
}
#endif

#endif	/* TMR2_H */

