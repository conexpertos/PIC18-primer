
#include "pwm1.h"

void PWM1_Initialize(void){
    BSF(TRISC,2); // DISABLE OUTPUT RC2
    PR2=PWMper;  //@48MZ, psc 1:16, fpwm=2.93kHz /341.3us
    CCP1CON= ((CCP1CON & 0XF0)|(CCP1M &0X0F)) ;// [XXXX[CCP1M]]
    //CCP1CON|=(CCP1M<<2);
    //Duty0 setup:
    PWM1_LoadDutyValue(Duty0);
    //CCPR1L=Duty0>>2;
    //CCP1CONbits.DC1B=0 ; //00
    //
    TMR2_initialize();//tmr2 initialize
    while(PIR1bits.TMR2IF != 1);
    BCF(TRISC,2); //ENABLE OUTPUT RC2
    //__delay_us(100);
    //PIR1bits.TMR2IF=0; //RESET IF, manual
}

void PWM1_LoadDutyValue(uint16_t dutyValue){
    CCPR1L = ((dutyValue & 0x03FC)>>2);
    //CCPR1L=(uint8_t)dutyValue>>2; //type casting!!!
    CCP1CON = (uint8_t)((CCP1CON & 0xCF) | ((dutyValue & 0x0003)<<4));
    //CCP1CONbits.DC1B=(dutyValue & 0x03); //00
   // PIR1bits.TMR2IF=0; //RESET IF, manual
}
