#include "keypad.h"

const char keypad[4][3] = {
    {'7', '8', '9'},
    {'4', '5', '6'},
    {'1', '2', '3'},
    {'*', '0', '#'}
};

void keypad_init(void) {
    // RA1, RA2, RA3 como salidas (columnas)
    TRISA &= ~((1 << 1) | (1 << 2) | (1 << 3));
    //LATA |= (1 << 1) | (1 << 2) | (1 << 3); // Inicialmente en alto
    LATA &= ~((1 << 1) | (1 << 2) | (1 << 3)); // Todas en bajo

    // RB4?RB7 como entradas (filas)
    TRISB |= 0xF0;
    ANSELB &= 0x0F; // Desactiva funciones anal�gicas
    WPUB |= 0xF0;   // Pull-ups internos
    INTCON2bits.RBPU = 0;

    IOCB |= 0xF0;   // Habilita IOC para RB4-RB7
    INTCONbits.IOCIE = 1; // Habilita interrupci�n IOC en Puerto B
   
    // INTCONbits.GIE = 1;  // Habilita interrupciones globales
}

char read_keypad(void) {
    for (uint8_t col = 0; col < 3; col++) {
        // Pone una columna en bajo a la vez
        LATA |= (1 << 1) | (1 << 2) | (1 << 3); // Todas en alto
        LATA &= ~(1 << (col + 1)); // Activa columna actual

        __delay_us(10); // Breve retardo para estabilizaci�n

        uint8_t row_val = (PORTB & 0xF0) >> 4;
        if (row_val != 0x0F) {
            for (uint8_t row = 0; row < 4; row++) {
                if (!(row_val & (1 << row))) {
                    return keypad[row][col];
                }
            }
        }
        LATA &= ~((1 << 1) | (1 << 2) | (1 << 3)); // Todas en bajo, GenIA omisi�n!!!
    }
    return 0;
}
