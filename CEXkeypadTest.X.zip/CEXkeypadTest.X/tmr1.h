
#ifndef TMR1_H
#define TMR1_H



#include <stdbool.h>
#include <stdint.h>
#include "pin_manager.h"
#include "macrosFZ.h"

#ifdef __cplusplus  // Provide C++ Compatibility

    extern "C" {

#endif

#define TMR1_INTERRUPT_TICKER_FACTOR    1

void TMR1_Initialize(void);

void TMR1_StartTimer(void);


void TMR1_StopTimer(void);


void TMR1_WriteTimer(uint16_t timerVal);

void TMR1_Reload(void);

//void TMR1_StartSinglePulseAcquisition(void);

//uint8_t TMR1_CheckGateValueStatus(void);

void TMR1_ISR(void);

void TMR1_CallBack(void);

 void TMR1_SetInterruptHandler(void (* InterruptHandler)(void));

extern void (*TMR1_InterruptHandler)(void);

void TMR1_DefaultInterruptHandler(void);


#ifdef __cplusplus  // Provide C++ Compatibility

    }

#endif

#endif // TMR1_H
/**
 End of File
*/