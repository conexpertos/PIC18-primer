/* 
 * File:   interrupts.h
 * Author: AdminFZ
 *
 * Created on 23 de mayo de 2025, 15:23
 */

#ifndef INTERRUPTS_H
#define	INTERRUPTS_H
#endif

#include <xc.h>
#include "dduc.h"
#include "global.h"

//Macros 
#define INTERRUPT_GlobalInterruptEnable() (INTCONbits.GIE = 1)
#define INTERRUPT_GlobalInterruptDisable() (INTCONbits.GIE = 0)
#define INTERRUPT_PeripheralInterruptEnable() (INTCONbits.PEIE = 1)
#define INTERRUPT_PeripheralInterruptDisable() (INTCONbits.PEIE = 0)


void  INTERRUPT_Initialize (void);

void __interrupt() Interrupt_manager(void);

