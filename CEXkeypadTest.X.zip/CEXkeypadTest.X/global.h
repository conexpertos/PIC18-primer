/* 
 * File:   global.h
 * Author: AdminFZ
 *
 * Created on 23 de mayo de 2025, 15:31
 */

#ifndef GLOBAL_H
#define	GLOBAL_H
#endif
#include <xc.h>

volatile uint8_t key_flag;
volatile uint8_t row_pressed;
volatile uint16_t timer1ReloadVal;