#include "tmr2.h"

  void TMR2_Start(void){
      T2CONbits.TMR2ON=1;
  }
  void TMR2_Stop(void){
      T2CONbits.TMR2ON=0;
      
  }

  void TMR2_initialize(void){
      TMR2_Stop();
      PIR1bits.TMR2IF=0;
      //T2CON|=psc2;
      T2CON = (uint8_t)((T2CON & 0x03) | ((psc2 & 0x03)));
      TMR2_Start();
  }
