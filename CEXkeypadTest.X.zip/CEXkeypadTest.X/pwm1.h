/* 
 * File:   pwm1.h
 * Author: AdminFZ
 *
 * Created on May 29, 2025, 3:25 PM
 */

#ifndef PWM1_H
#define	PWM1_H

#include <xc.h>
#include "device_config.h"
#include <stdint.h>
#include <stdbool.h>
#include "macrosFZ.h"
#include "tmr2.h"

#ifdef	__cplusplus
extern "C" {
#endif

#define PWMper 0xFF  //255  //Fmin 2.92kHz @ fosc 48MHz 341.33us psc2=16:1
#define Duty0  512  //512  //Duty inicial, de prueba
#define CCP1M  0x0F //mode PWM   0B11XX  
    
void PWM1_Initialize(void);

void PWM1_LoadDutyValue(uint16_t dutyValue);


#ifdef	__cplusplus
}
#endif

#endif	/* PWM1_H */

