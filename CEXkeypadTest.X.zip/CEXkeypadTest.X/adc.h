/* 
 * File:   adc.h
 * Author: AdminFZ
 *
 * Created on 30 de mayo de 2025, 12:09
 */

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
#include "macrosFZ.h"
#include "pin_manager.h"    
//ADCON2:
#define convclock 0x03   //0-7 Frc= 3 o 7, Fosc/ 2,8,32,rc,4,16,64,rc.
                        //ADCON2,pg.296  Frc=600kHz Nominal Tad=1.667useg    
#define acqt 0x05        //0-7 , 0 manual, 5=12Tad.  m,2,4,6,8,12,16,20    
//
//ADCON1:
#define pvcfg 0x0   //0 = AVdd positive voltage reference    
#define nvcfg 0x0  //0 = AVss  negative voltage reference    
#define nsamples 8  //n�mero de muestras para hacer promedio de cada medici�n    
//    

void ADC_Initialize(void);

uint16_t ADC_Read (uint8_t channel);

#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

