/* 
 * File:   keypad.h
 * Author: AdminFZ
 *
 * Created on 23 de mayo de 2025, 13:09
 */
#include <xc.h>
#include "device_config.h"
#include "macrosFZ.h"

#ifndef KEYPAD_H
#define	KEYPAD_H

void keypad_init(void);
char read_keypad(void);


#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* KEYPAD_H */

