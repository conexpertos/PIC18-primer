/*
 device config
 * fzamora 
 * 2025-1
 
 */
#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

#define _XTAL_FREQ 48000000

#endif	/* DEVICE_CONFIG_H */
/**
 End of File
*/
