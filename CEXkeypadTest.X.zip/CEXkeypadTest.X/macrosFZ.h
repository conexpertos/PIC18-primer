/* 
 * File:   macrosFZ.h
 * Author: AdminFZ
 *
 * Created on 23 de mayo de 2025, 13:20
 */

#ifndef MACROSFZ_H
#define	MACROSFZ_H
#endif

#include <xc.h>

#define  BTG(var,bit) (var^=1<<bit)
#define  BSF(var,bit) (var|=1<<bit)
#define  BCF(var,bit) (var&=~(1<<bit))
