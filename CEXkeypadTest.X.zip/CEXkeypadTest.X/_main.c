/* 
 * File:   _main.c
 * Author: AdminFZ
 * Versiones: CEXduino 1.4 hardware dev board
 * V0:  blinker RA4, creado copiando algunos archivos de proy MCC pero sin usar MCC
 * V1:  demo keypad 4x3 con salida uart (chatGPT errores, editado y corregido)
 * V2:  beep 2-3kHz con sounder en debounce, a partir de tmr1 int.
 * V3:  habilitar sounder beep por PWM (ECCP, TMR2)
 * V4:  enviar valores ADC como #hex y como voltaje estimado de lectura en RV1(RA0 AN0)
 * V4.2: adc controla duty cycle de pwm1 sounder, se filtran mediciones por promedio de nsamples
 * Created on 23 de mayo de 2025, 12:31
 */

#include "dduc.h"
#include "global.h"

/*
 * 
 */
void main(void)
{
    
    Setup();  //Incluye Oscillator_Init()
    
    //Interrupts...
      // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

   printf("Teclado listo...\r\n");
       
    //loop...
    while(true)
    {
     //BTG(LATA,4);  //LEDG   
     //__delay_ms(500);
     
       if (key_flag) {
           
           char tecla=read_keypad();
           uint16_t adc_res=ADC_Read(0);
           PWM1_LoadDutyValue(adc_res);
           BTG(LATA,4);  //LEDG   test 
           if((PORTB & 0xF0) != 0xF0)  //key pressed, else, released
           {
             
               //tecla = read_keypad();
               //PIE1bits.TMR1IE = 1;
            BCF(TRISC,2);  //CCP1 digital out
             TMR2_Start();  //enable pwm1 = beep
             
           }
              __delay_ms(20); // Debounce.... on press AND release
            //PIE1bits.TMR1IE = 0;
               TMR2_Stop();     //disable pwm1
            BSF(TRISC,2);  //CCP1 z HIGH
           //char tecla = read_keypad();   
                                    
            if (tecla) {
                printf("Tecla presionada: %c\r\n", tecla);
                printf("ADCread: %u\r\n",adc_res);
            }
            key_flag = 0;   
       }
     
    }
    
}

