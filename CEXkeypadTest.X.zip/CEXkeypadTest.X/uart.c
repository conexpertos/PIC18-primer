#include "uart.h"


void uart_init(void) {
    TRISC6 = 1; // TX
    TRISC7 = 1; // RX
    SPBRG = (_XTAL_FREQ / (64UL * 9600)) - 1; // Baudrate 9600
     TXSTAbits.BRGH = 0; // Low speed
    BAUDCTLbits.BRG16 = 0; //8 bits
    // SPBRGH = ((_XTAL_FREQ / (4UL * mybaudrate)) - 1)>>8; // Baudrate 9600
    // SPBRG = ((_XTAL_FREQ / (4UL * mybaudrate)) - 1)& 0FFh; // Baudrate 9600
    //TXSTAbits.BRGH = 1; // High speed
    //BAUDCTLbits.BRG16 = 1; //16 bits
    TXSTAbits.SYNC = 0;
    RCSTAbits.SPEN = 1;
    TXSTAbits.TXEN = 1;
    RCSTAbits.CREN = 1;
}

void putch(char data) {
    while (!TXSTAbits.TRMT);
    TXREG = data;
}