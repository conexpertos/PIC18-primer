/* 
 * File:   uart.h
 * Author: AdminFZ
 *
 * Created on 23 de mayo de 2025, 13:38
 */

#ifndef UART_H
#define	UART_H
#endif

#include <xc.h>
#include "device_config.h"

#define mybaudrate 9600UL

void uart_init(void);
void putch(char data);