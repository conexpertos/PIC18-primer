#include "adc.h"



void ADC_Initialize(void){
    ADCON0bits.ADON=0;  //adc off
    ADCON2bits.ADFM=1;  //1=right 0=left
    //acquisition time and conversion clock
    ADCON2 = ((ADCON2 & 0x80) | ((acqt & 0x7)<<3)|((convclock & 0x7)));
    //Trigsel bit 7=0: ccp2/ctmu, positive and negative voltage reference cfg
    ADCON1 = ((ADCON1 & 0x00) | ((pvcfg & 0x3)<<2)|((nvcfg & 0x3)));
    
    // Asegurarse que ANx se configuran como pines Anal�gicos (ANSELx)
    BSF (TRISA,0); //ENTRADA DIGITAL
    BSF(ANSELA,0); //ENTRADA ANAL�GICA
}

uint16_t ADC_Read (uint8_t channel){
     ADCON0 = (uint8_t)((ADCON0 & 0x00) | ((channel & 0x1F)<<2));
     //borrar ADCIF si se usa y habilitar ADCIE y GIE
     ADCON0bits.ADON=1;  //ADC on
     //delay for ACQT si es manual!
     uint16_t adcread=0 ;
     uint8_t i;
     for(i=0;i < nsamples;i++){
          ADCON0bits.GO=1; // Start conversion... antes espera ACQT si es auto
    while (ADCON0bits.GO)
        ; // Espera a que termine
    adcread += (uint16_t)(ADRESH << 8) | ADRESL;
          // ***se recomienda filtrar ruido, promediando 2^n resultados!***
     }
    ADCON0bits.ADON=0;  //ADC off  
    return ( adcread / nsamples);
    
}