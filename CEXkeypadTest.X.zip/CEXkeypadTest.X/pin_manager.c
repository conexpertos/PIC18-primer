
#include "pin_manager.h"
#include "global.h"





void PIN_MANAGER_Initialize(void)
{
    /**
    LATx registers
    */
    LATA = LATA_init;
    LATB = LATB_init;
    LATC = LATC_init;

    /**
    TRISx registers
    */
    TRISA = TRISA_init;
    TRISB = TRISB_init;
    TRISC = TRISC_init;

    /**
    ANSELx registers
    */
    ANSELC = ANSELC_init;
    ANSELB = ANSELB_init;
    ANSELA = ANSELA_init;

    /**
    WPUx registers
    */
    WPUB = WPUB_init;
    INTCON2bits.nRBPU = 0;
   
}
  
void PIN_MANAGER_IOC(void)  //ISR
{   
	// Clear global Interrupt-On-Change flag
     // Determina qu� fila fue activada
        row_pressed = (PORTB & 0xF0) >> 4;
        key_flag = 1;
    
    INTCONbits.IOCIF = 0;  //borrar s�lo despu�s de leer PORTB!!!
}

/**
 End of File
*/
