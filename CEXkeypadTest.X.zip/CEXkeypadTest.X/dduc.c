#include "dduc.h"

// Variables globales

void Setup()
{
    INTERRUPT_Initialize();
    PIN_MANAGER_Initialize();
    Oscillator_Init();
    keypad_init();
    uart_init();
    TMR1_Initialize();
    PWM1_Initialize();
        TMR2_Stop(); //para usar durante debounce y no permanente
    ADC_Initialize();
    //EXT_INT_Initialize();
        
}

void Oscillator_Init()
{
   // SCS FOSC; IDLEN disabled; IRCF 16MHz; 
    OSCCON = 0x70;
    // INTSRC INTRC_31_25KHz; PLLEN disabled; PRISD disabled; SOSCGO disabled; 
    OSCCON2 = 0x00;
    // SPLLMULT 3xPLL; TUN 0; 
    OSCTUNE = 0x80;
    // ACTSRC SOSC; ACTUD enabled; ACTEN disabled; 
    ACTCON = 0x00;
    // Wait for PLL to stabilize
#ifndef mpsim    
    while(PLLRDY == 0)
    {
    }
#endif      
    
}
