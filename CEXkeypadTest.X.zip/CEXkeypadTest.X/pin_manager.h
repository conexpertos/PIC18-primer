/* 
 * File:   pin_manager.h
 * Author: AdminFZ
 *
 * Created on 23 de mayo de 2025, 13:12
 */

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

#define LATA_init 0xFF
#define LATB_init 0xFF
#define LATC_init 0xFF

#define TRISA_init 0b11100001
#define TRISB_init 0b11111110
#define TRISC_init 0b11111011

#define ANSELA_init 0X00
#define ANSELB_init 0X00
#define ANSELC_init 0X00

#define WPUB_init 0XF0

// get/set LED_G aliases
#define LED_G_TRIS                 TRISAbits.TRISA4
#define LED_G_LAT                  LATAbits.LATA4
#define LED_G_PORT                 PORTAbits.RA4
#define LED_G_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define LED_G_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define LED_G_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define LED_G_GetValue()           PORTAbits.RA4
#define LED_G_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define LED_G_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)

// get/set B0 aliases
#define B0_TRIS                 TRISBbits.TRISB0
#define B0_LAT                  LATBbits.LATB0
#define B0_PORT                 PORTBbits.RB0
#define B0_WPU                  WPUBbits.WPUB0
#define B0_ANS                  ANSELBbits.ANSB0
#define B0_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define B0_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define B0_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define B0_GetValue()           PORTBbits.RB0
#define B0_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define B0_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define B0_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define B0_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define B0_SetAnalogMode()      do { ANSELBbits.ANSB0 = 1; } while(0)
#define B0_SetDigitalMode()     do { ANSELBbits.ANSB0 = 0; } while(0)

// get/set SW3 aliases
#define SW3_TRIS                 TRISBbits.TRISB2
#define SW3_LAT                  LATBbits.LATB2
#define SW3_PORT                 PORTBbits.RB2
#define SW3_WPU                  WPUBbits.WPUB2
#define SW3_ANS                  ANSELBbits.ANSB2
#define SW3_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define SW3_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define SW3_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define SW3_GetValue()           PORTBbits.RB2
#define SW3_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define SW3_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define SW3_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define SW3_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define SW3_SetAnalogMode()      do { ANSELBbits.ANSB2 = 1; } while(0)
#define SW3_SetDigitalMode()     do { ANSELBbits.ANSB2 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);

